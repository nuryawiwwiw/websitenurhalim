<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "nurya";

$dbconnect = new mysqli("$host","$user","$pass","$db");

?>