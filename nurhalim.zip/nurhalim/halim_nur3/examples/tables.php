
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
  X Sport store
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a href="https://www.creative-tim.com" class="simple-text logo-mini">
          <div class="logo-image-small">
            <img src="../assets/img/logo-small.png">
          </div>
          <!-- <p>CT</p> -->
        </a>
        <a href="https://www.creative-tim.com" class="simple-text logo-normal">
          Kelompok 13
          <!-- <div class="logo-image-big">
            <img src="../assets/img/logo-big.png">
          </div> -->
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li>
            <a href="./index.php">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
       
                    <li class="active ">
            <a href="./tables.php">
              <i class="nc-icon nc-tile-56"></i>
              <p>Data Barang</p>
            </a>
          </li>
          <li>
            <a href="./typography.php">
              
              <p>Kontak Person</p>

                <li>
            <a href="./Login.php">
              <p>Log Out</p>
            </a>
          </li>

            </a>
          </li>
         
        </ul>
      </div>
    </div>
    <div class="main-panel">

      <!-- End Navbar -->
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Data barang</h4>
              </div>
             <a href="inputdata.php" class="btn btn-primary">Input Data</a>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                       ID
                      </th>
                      <th>
                       Kode
                      </th>
                      <th>
                        Nama barang
                      </th>
                      <th>
                        Harga
                      </th>
                      <th>
                       Stok
                      </th>
                      <th>
                        Diskon
                      </th>
                      <th>
                        Suplier
                      </th>
                         <th>
                      Aksi
                      </th>
                    </thead>

                          <tbody>
                            
                     
<?php       

  include 'koneksi.php';

    $no = 1;

    $number = mysqli_query($dbconnect, "SELECT * FROM jos");



    while ($query = mysqli_fetch_assoc($number)) {

?>
  
  <form  action="" method="post">
    
       <tr>
        
         <td><?php echo $no++;  ?></td>

         <td><?php echo $query ['kode']  ?></td>

         <td><?php echo $query ['nama_barang']  ?></td>

         <td><?php echo $query ['harga'] ?></td>

         <td><?php echo $query ['stok']  ?></td>

          <td><?php echo $query ['diskon']  ?></td>

         <td><?php echo $query ['supplier']  ?></td>

                  
         
          </form>

            <td>
          
          <a href="updatedata.php?id=<?php echo $query['id']?>" class="btn btn-primary">Edit</a>

          <a href="proseshapusdata.php?id=<?php echo $query ['id']?>" class="btn btn-danger" onclick="return confirm ('Opo sampeyan yakin arep mbusak akun mu?? dengan id <?php echo $query ['id']?>??')">Hapus</a>
         </td>
        

<?php   }   ?>

        </tbody>
        
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <footer>
            <div class="container">
        <small><center>Copyright &copy; 2022 - M Halim M.S/16/XII RPL2 & Nuryanto/20/XII RPL2</center></small>        
            </div>
        </footer>
</body>

</html>