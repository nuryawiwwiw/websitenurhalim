<?php

include 'koneksi.php';

$kode= $_POST['kode'];
$namabarang= $_POST['nama_barang'];
$harga= $_POST['harga'];
$stok= $_POST['stok'];
$diskon= $_POST['diskon'];
$supplier= $_POST['supplier'];



 mysqli_query($dbconnect, "INSERT INTO jos VALUES ( NULL, '$kode','$namabarang','$harga','$stok', '$diskon', '$supplier')");

 header("location:tables.php")
 ?>