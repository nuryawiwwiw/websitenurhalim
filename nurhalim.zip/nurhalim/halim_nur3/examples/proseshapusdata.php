<?php include 'koneksi.php';

$id = $_GET['id'];


mysqli_query($dbconnect, "DELETE FROM jos WHERE id = '$id' "); 


header("location:tables.php");
?>