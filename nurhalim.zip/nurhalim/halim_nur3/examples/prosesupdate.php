<?php

 include 'koneksi.php';
  $id = $_POST['id'];
  $kode = $_POST['kode'];
  $namabarang = $_POST['nama_barang'];
  $harga = $_POST['harga'];
  $stok = $_POST['stok'];
  $sdiskon = $_POST['diskon'];
  $supplier = $_POST['supplier'];



  mysqli_query($dbconnect, "UPDATE `jos` SET `kode`='$kode' , `nama_barang`='$namabarang' , `harga`='$harga' , `stok`='$stok', `diskon`='$diskon' , `supplier`='$supplier' WHERE `id`='$id' ");
  header("location:tables.php");
  ?>